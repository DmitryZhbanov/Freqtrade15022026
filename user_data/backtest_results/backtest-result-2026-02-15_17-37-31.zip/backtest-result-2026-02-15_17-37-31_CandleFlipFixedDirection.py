from datetime import datetime
from typing import Optional

import pandas as pd
from freqtrade.strategy import IStrategy
from freqtrade.persistence import Trade


class CandleFlipFixedDirection(IStrategy):
    """
    Logic:
    - On every 15m candle close:
        1. If no open trade -> open trade in predefined direction.
        2. If trade exists -> close it at market.
    - TP/SL handled via minimal_roi + stoploss.
    """

    # === USER SETTINGS ===
    timeframe = "15m"

    # Direction: "long" or "short"
    trade_direction = "long"

    # Fixed TP in percent (0.01 = 1%)
    fixed_tp = 0.07

    # Fixed SL in percent (-0.01 = -1%)
    stoploss = -0.007

    # ROI configuration (TP)
    minimal_roi = {
        "0": 0.07  # same as fixed_tp
    }

    process_only_new_candles = True
    startup_candle_count = 1

    # Required for futures shorting
    can_short = True

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0

        # Entry on every candle close
        if self.trade_direction == "long":
            dataframe.loc[dataframe.index[-1], "enter_long"] = 1
        else:
            dataframe.loc[dataframe.index[-1], "enter_short"] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0

        # Force exit on every candle close
        if self.trade_direction == "long":
            dataframe.loc[dataframe.index[-1], "exit_long"] = 1
        else:
            dataframe.loc[dataframe.index[-1], "exit_short"] = 1

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: Optional[float] = None, max_leverage: float = 20.0,
                 entry_tag: Optional[str] = None, side: Optional[str] = None, **kwargs) -> float:
        return 1.0  # change if needed
