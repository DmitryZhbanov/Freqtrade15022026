from datetime import datetime
from typing import Optional

import pandas as pd
from freqtrade.strategy import IStrategy


class CandleFlipFixedDirection(IStrategy):
    """
    Opens a position every candle.
    Holds exactly 1 candle.
    If TP/SL hits earlier -> closes earlier.
    """

    # === BASIC SETTINGS ===
    timeframe = "15m"
    process_only_new_candles = True
    startup_candle_count = 1

    # Direction: "long" or "short"
    trade_direction = "long"

    # === RISK SETTINGS ===
    minimal_roi = {
        "0": 0.07  # 7% TP
    }

    stoploss = -0.007  # -0.7% SL

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    can_short = True

    # ==========================
    # Indicators
    # ==========================

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        return dataframe

    # ==========================
    # Entry logic
    # ==========================

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0

        if self.trade_direction == "long":
            dataframe.loc[:, "enter_long"] = 1
        else:
            dataframe.loc[:, "enter_short"] = 1

        return dataframe

    # ==========================
    # Exit logic (exit next candle)
    # ==========================

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0

        if self.trade_direction == "long":
            dataframe["exit_long"] = dataframe["enter_long"].shift(1).fillna(0)
        else:
            dataframe["exit_short"] = dataframe["enter_short"].shift(1).fillna(0)

        return dataframe

    # ==========================
    # Futures leverage (optional)
    # ==========================

    def leverage(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_leverage: Optional[float] = None,
        max_leverage: float = 20.0,
        entry_tag: Optional[str] = None,
        side: Optional[str] = None,
        **kwargs
    ) -> float:
        return 1.0
